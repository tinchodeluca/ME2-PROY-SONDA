'''
Created on 9 nov. 2023

@author: mdelu
'''
import numpy as np

class vna_proc_file(object):
    '''
    classdocs
    '''
    def __init__(self, file_path, file_name):
        
        file_path += file_name
        
        header_start  = '#'
        data_start    = '!'
        self.out_dict = {'Data' : [],
                         'Index': [],
                         'Frec' : [],
                        }
        
        frecuencies = np.array([])
        reals       = np.array([])
        imgs        = np.array([])
        
        try: 
            file = open(file_path, "r")
        except: 
            print('TODO: No se puede abrir')
            return 404
        
        file_list = file.readlines()
        file.close()
        
        for line in file_list[12:]:
            values = line.strip().split('\t')
            frecuencies = np.append(frecuencies, int(values[0]))
            reals       = np.append(reals, float(values[1]))
            imgs        = np.append(imgs, float(values[2]))
        
        self.out_dict['Data'   ] = file_list[0:11]
        self.out_dict['Index'  ] = file_list[11][1:].split(' ')
        self.out_dict['Frec'   ] = frecuencies
        self.out_dict['Img'    ] = imgs
        self.out_dict['Real'   ] = reals
        self.out_dict['Complex'] = reals +1j*imgs 
    
    def data(self):
        return self.out_dict