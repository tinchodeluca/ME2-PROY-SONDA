function agua = Patron_agua_destilada(f)
%er complejo del agua destilada 

agua=4.6+(78.3-4.6)./(1+(1j*2*pi*f*8.07e-12));%.^(1-0.014));


end

