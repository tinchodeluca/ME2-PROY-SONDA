function [  ] = EndVNA( N9917A )
%ENDVNA Summary of this function goes here
%   Detailed explanation goes here

fclose(N9917A);

delete(N9917A);

%clear;

        
end

